const { modul } = require('../module');
const judul7 = `∅Produk Tidak Tersedia∅`

//EDIT BARANG YANG MAU DI JUAL DI BAWAH⬇️
const produk7 = `🚫TIDAK ADA PRODUK🚫

BTW BOLEH BANTU SUPORT NYA GA😅
CUMA SUBCRIBE CHANEL MTS7YOU 🙏
https://www.youtube.com/@mts_store_real`

module.exports = { judul7,produk7 }