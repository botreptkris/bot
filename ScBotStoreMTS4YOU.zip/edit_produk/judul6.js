const { modul } = require('../module');
const judul6 = `∅Produk Tidak Tersedia∅`

//EDIT BARANG YANG MAU DI JUAL DI BAWAH⬇️
const produk6 = `🚫TIDAK ADA PRODUK🚫

BTW BOLEH BANTU SUPORT NYA GA😅
CUMA SUBCRIBE CHANEL MTS6YOU 🙏
https://www.youtube.com/@mts_store_real`

module.exports = { judul6,produk6 }