const { modul } = require('../module');
const edit_payment = `Di Bawah`

//EDIT PAYMENT GOPAY DI BAWAH
const QRgopay = `https://d.top4top.io/p_265331x8e2.jpg`
const NOgopay = `08123456789`

//EDIT PAYMENT DANA DI BAWAH
const QRdana = `https://d.top4top.io/p_265331x8e2.jpg`
const NOdana = `08123456789`

//EDIT PAYMENT OVO DI BAWAH
const QRovo = `https://d.top4top.io/p_265331x8e2.jpg`
const NOovo = `08123456789`

//EDIT PAYMENT SHOPEE DI BAWAH
const QRshopee = `https://d.top4top.io/p_265331x8e2.jpg`
const NOshopee = `08123456789`

//EDIT ALL PAYMENT DI BAWAH
const QRallpay = `https://d.top4top.io/p_265331x8e2.jpg`

module.exports = { edit_payment,QRgopay,NOgopay,QRdana,NOdana,QRovo,NOovo,QRshopee,NOshopee,QRallpay }