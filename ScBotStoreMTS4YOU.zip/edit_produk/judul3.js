const { modul } = require('../module');
const judul3 = `∅Produk Tidak Tersedia∅`

//EDIT BARANG YANG MAU DI JUAL DI BAWAH⬇️
const produk3 = `🚫TIDAK ADA PRODUK🚫

BTW BOLEH BANTU SUPORT NYA GA😅
CUMA SUBCRIBE CHANEL MTS4YOU 🙏
https://www.youtube.com/@mts_store_real`

module.exports = { judul3,produk3 }