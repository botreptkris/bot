const { modul } = require('../module');
const judul1 = `♕𝐌𝐓𝐒 𝐒𝐓𝐎𝐑𝐄♕`

//EDIT BARANG YANG MAU DI JUAL DI BAWAH⬇️
const produk1 = `FF 70💎 Rp 10.000`

module.exports = { judul1,produk1 }